# Valet-Homework

To run the planner, run the main\_{ROBOT_TYPE} file. There are three types: DeliveryBot, PoliceCar, and TrailerBot.
Each bot is each of the different required vehicles for the assignment. The GUI should automatically display. Make
sure you have pygame and numpy installed before running, as the script depends on both packages.

The debug scripts can help visualize the planning process, if desired. Note that it is not as polished as the main files,
since they were created to solely assist with troubleshooting.

Thank you!
